#!/bin/bash

FILE="insurance.txt"

while true; do
    echo ""
    echo "1. Create New Vehicle Insurance Policy"
    echo "2. Display Created Policy"
    echo "3. Delete Policy"
    echo "4. Exit"
    read -p "Enter choice (1-4): " choice

    case $choice in
        1)
            read -p "Enter Vehicle No: " vno
            read -p "Enter Vehicle Type (2-wheeler/4-wheeler): " vtype
            read -p "Enter Customer Name: " cname
            read -p "Enter Engine No: " eng
            read -p "Enter Chasis No: " chasis
            read -p "Enter Phone No: " phone
            read -p "Enter Premium Amount: " prem
            read -p "Enter Type (Full Insurance/ThirdParty): " type
            read -p "Enter From Date: " fdate
            read -p "Enter To Date: " tdate
            read -p "Enter Underwriter Id: " uwid

            echo "$vno|$vtype|$cname|$eng|$chasis|$phone|$prem|$type|$fdate|$tdate|$uwid" >> "$FILE"
            echo "Policy record saved successfully."
            ;;
        2)
            if [ ! -f "$FILE" ] || [ ! -s "$FILE" ]; then
                echo "No policies found."
            else
                echo ""
                echo "VehicleNo | PremiumAmount"
                awk -F'|' '{print $1 " | " $7}' "$FILE"
            fi
            ;;
        3)
            if [ ! -f "$FILE" ]; then
                echo "File not found."
            else
                read -p "Enter Vehicle No to delete: " del_vno
                if grep -q "^$del_vno|" "$FILE"; then
                    grep -v "^$del_vno|" "$FILE" > temp.txt && mv temp.txt "$FILE"
                    echo "Policy record deleted successfully."
                else
                    echo "Vehicle No not found."
                fi
            fi
            ;;
        4)
            echo "Exiting program."
            exit 0
            ;;
        *)
            echo "Invalid choice."
            ;;
    esac
done
