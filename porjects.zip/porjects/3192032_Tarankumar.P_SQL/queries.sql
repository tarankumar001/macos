CREATE DATABASE IF NOT EXISTS StarProtect;
USE StarProtect;

CREATE TABLE Underwriter (
    UnderwriterId INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(50) NOT NULL,
    DOB DATE NOT NULL,
    JoiningDate DATE NOT NULL,
    DefaultPassword VARCHAR(50) NOT NULL
);

INSERT INTO Underwriter (Name, DOB, JoiningDate, DefaultPassword) VALUES
('Rahul Sharma', '1995-05-15', '2023-01-10', 'Rahul@123'),
('Priya Verma', '1998-08-20', '2023-06-01', 'Priya#456');

CREATE TABLE Insurance (
    PolicyNo INT AUTO_INCREMENT PRIMARY KEY,
    VehicleNo VARCHAR(20) NOT NULL,
    VehicleType VARCHAR(20) NOT NULL,
    CustomerName VARCHAR(50) NOT NULL,
    EngineNo INT NOT NULL,
    ChasisNo INT NOT NULL,
    PhoneNo BIGINT NOT NULL,
    Type VARCHAR(20) NOT NULL,
    PremiumAmt DECIMAL(10, 2) NOT NULL,
    FromDate DATE NOT NULL,
    ToDate DATE NOT NULL,
    UnderwriterId INT NOT NULL,
    FOREIGN KEY (UnderwriterId) REFERENCES Underwriter(UnderwriterId)
);

INSERT INTO Insurance (VehicleNo, VehicleType, CustomerName, EngineNo, ChasisNo, PhoneNo, Type, PremiumAmt, FromDate, ToDate, UnderwriterId) VALUES
('KA 01 AB 1234', '2-wheeler', 'Amit Kumar', 12345, 67890, 9876543210, 'Full Insurance', 1500.00, '2024-01-01', DATE_ADD('2024-01-01', INTERVAL 365 DAY), 1),
('MH 02 CD 5678', '4-wheeler', 'Suresh Patel', 54321, 09876, 9123456789, 'ThirdParty', 2200.00, '2024-02-15', DATE_ADD('2024-02-15', INTERVAL 365 DAY), 1),
('DL 03 EF 9012', '2-wheeler', 'Neha Gupta', 11223, 44556, 9988776655, 'ThirdParty', 750.00, '2023-05-10', DATE_ADD('2023-05-10', INTERVAL 365 DAY), 2),
('TN 04 GH 3456', '4-wheeler', 'Vikram Singh', 99887, 77665, 9876123450, 'Full Insurance', 5000.00, '2023-01-01', DATE_ADD('2023-01-01', INTERVAL 365 DAY), 2);

SELECT * FROM Insurance WHERE PolicyNo = 1;

SELECT UnderwriterId, COUNT(PolicyNo) AS TotalVehicles
FROM Insurance
GROUP BY UnderwriterId;

SELECT * FROM Insurance WHERE ToDate < CURRENT_DATE();

DELETE FROM Insurance WHERE UnderwriterId = 1;
DELETE FROM Underwriter WHERE UnderwriterId = 1;
