from datetime import datetime, timedelta
from vehicle_insurance import VehicleInsurance, calculate_premium
import storage


class UnderwriterService:
    def __init__(self):
        self.logged_in_underwriter_id = None

    def underwriter_login(self):
        print("\nUnderwriter Login")
        raw_id = input("Enter Underwriter ID: ").strip()
        if not raw_id.isdigit():
            print("Invalid ID format.")
            return False

        uw_id = int(raw_id)
        password = input("Enter Password: ").strip()

        underwriters = storage.load_underwriters()
        found = next((u for u in underwriters if u.underwriter_id == uw_id and u.password == password), None)

        if found:
            self.logged_in_underwriter_id = uw_id
            print("Login successful.")
            return True
        else:
            print("Invalid Underwriter ID or Password.")
            return False

    def underwriter_menu(self):
        if not self.logged_in_underwriter_id:
            print("No active underwriter session.")
            return

        while True:
            print(f"\nUNDERWRITER MENU (ID: {self.logged_in_underwriter_id})")
            print("1. Create a new Vehicle Insurance")
            print("2. Renewal of a Policy")
            print("3. Changing of a policy")
            print("4. View Policy")
            print("5. Logout")

            choice = input("Enter your choice (1-5): ").strip()

            if choice == "1":
                self.create_vehicle_insurance()
            elif choice == "2":
                self.renew_policy()
            elif choice == "3":
                self.change_policy_type()
            elif choice == "4":
                self.view_policy_menu()
            elif choice == "5":
                print("Logging out.")
                self.logged_in_underwriter_id = None
                break
            else:
                print("Invalid choice.")

    def create_vehicle_insurance(self):
        print("\nCreate New Vehicle Insurance")
        
        vehicle_no = input("Enter Vehicle No: ").strip()
        while not vehicle_no:
            print("Vehicle No cannot be empty.")
            vehicle_no = input("Enter Vehicle No: ").strip()

        while True:
            print("Select Vehicle Type:")
            print("1. 2-wheeler")
            print("2. 4-wheeler")
            vt_choice = input("Enter choice (1-2): ").strip()
            if vt_choice == "1" or vt_choice.lower() == "2-wheeler":
                vehicle_type = "2-wheeler"
                break
            elif vt_choice == "2" or vt_choice.lower() == "4-wheeler":
                vehicle_type = "4-wheeler"
                break
            else:
                print("Invalid Vehicle Type.")

        customer_name = input("Enter Customer Name: ").strip()
        while not customer_name:
            print("Customer Name cannot be empty.")
            customer_name = input("Enter Customer Name: ").strip()

        engine_no = input("Enter Engine No: ").strip()
        chasis_no = input("Enter Chasis No: ").strip()

        while True:
            phone_no = input("Enter Phone No (10 digits): ").strip()
            if phone_no.isdigit() and len(phone_no) == 10:
                break
            print("Invalid Phone Number. Must consist of exactly 10 digits.")

        while True:
            print("Select Insurance Type:")
            print("1. Full Insurance")
            print("2. ThirdParty")
            it_choice = input("Enter choice (1-2): ").strip()
            if it_choice == "1" or it_choice.lower() == "full insurance":
                insurance_type = "Full Insurance"
                break
            elif it_choice == "2" or it_choice.lower() == "thirdparty" or it_choice.lower() == "third party":
                insurance_type = "ThirdParty"
                break
            else:
                print("Invalid Insurance Type.")

        premium_amount = calculate_premium(vehicle_type, insurance_type)
        print(f"Premium Amount: {premium_amount}")

        while True:
            from_date_str = input("Enter From Date (DD-MM-YYYY): ").strip()
            try:
                from_date_obj = datetime.strptime(from_date_str, "%d-%m-%Y").date()
                break
            except ValueError:
                print("Invalid Date format. Use DD-MM-YYYY.")

        to_date_obj = from_date_obj + timedelta(days=365)
        to_date_str = to_date_obj.strftime("%d-%m-%Y")

        policies = storage.load_policies()
        policy_no = storage.generate_policy_no(policies)

        new_policy = VehicleInsurance(
            policy_no=policy_no,
            vehicle_no=vehicle_no,
            vehicle_type=vehicle_type,
            customer_name=customer_name,
            engine_no=engine_no,
            chasis_no=chasis_no,
            phone_no=phone_no,
            insurance_type=insurance_type,
            premium_amount=premium_amount,
            from_date=from_date_str,
            to_date=to_date_str,
            underwriter_id=self.logged_in_underwriter_id
        )

        policies.append(new_policy)
        storage.save_policies(policies)

        print(f"Vehicle Insurance created successfully. Policy No: {policy_no}")

    def renew_policy(self):
        print("\nRenewal of a Policy")
        raw_id = input("Enter Policy ID to renew: ").strip()
        if not raw_id.isdigit():
            print("Invalid Policy ID.")
            return

        policy_no = int(raw_id)
        policies = storage.load_policies()
        found = next((p for p in policies if p.policy_no == policy_no), None)

        if not found:
            print(f"Policy ID {policy_no} not found.")
            return

        print("Policy Details:")
        self._print_policy_details(found)

        confirm = input("Enter 'R' to confirm renewal: ").strip()
        if confirm.upper() != 'R':
            print("Renewal cancelled.")
            return

        while True:
            raw_prem = input("Enter the updated premium amount: ").strip()
            try:
                updated_premium = float(raw_prem)
                if updated_premium > 0:
                    break
                print("Premium amount must be greater than 0.")
            except ValueError:
                print("Invalid premium amount.")

        current_date = datetime.now().date()
        try:
            old_to_date = datetime.strptime(found.to_date, "%d-%m-%Y").date()
        except ValueError:
            old_to_date = current_date

        if current_date > old_to_date:
            new_from_date = current_date
        else:
            new_from_date = old_to_date + timedelta(days=1)

        new_to_date = new_from_date + timedelta(days=365)

        new_policy_no = storage.generate_policy_no(policies)

        renewed_policy = VehicleInsurance(
            policy_no=new_policy_no,
            vehicle_no=found.vehicle_no,
            vehicle_type=found.vehicle_type,
            customer_name=found.customer_name,
            engine_no=found.engine_no,
            chasis_no=found.chasis_no,
            phone_no=found.phone_no,
            insurance_type=found.type,
            premium_amount=updated_premium,
            from_date=new_from_date.strftime("%d-%m-%Y"),
            to_date=new_to_date.strftime("%d-%m-%Y"),
            underwriter_id=self.logged_in_underwriter_id
        )

        policies.append(renewed_policy)
        storage.save_policies(policies)

        print(f"Policy renewed successfully. New Policy No: {new_policy_no}")

    def change_policy_type(self):
        print("\nChanging of a Policy Type")
        raw_id = input("Enter Policy ID: ").strip()
        if not raw_id.isdigit():
            print("Invalid Policy ID.")
            return

        policy_no = int(raw_id)
        policies = storage.load_policies()
        found = next((p for p in policies if p.policy_no == policy_no), None)

        if not found:
            print(f"Policy ID {policy_no} not found.")
            return

        if found.type.lower() == "thirdparty":
            print("\nThere's no provision to update the policy type from Third party to full Insurance")
        elif found.type.lower() in ["full insurance", "fullinsurance"]:
            print("\nPress U to update the insurance type from full insurance to third party")
            user_input = input("Enter choice: ").strip()
            if user_input.upper() == 'U':
                found.type = "ThirdParty"
                found.premium_amount = calculate_premium(found.vehicle_type, "ThirdParty")
                storage.save_policies(policies)
                print(f"Policy type updated to ThirdParty successfully.")
            else:
                print("\nInvalid choice")
        else:
            print("\nInvalid choice")

    def view_policy_menu(self):
        while True:
            print("\nView Policy Menu")
            print("1. View all Insurance")
            print("2. View Insurance by Vehicle Id")
            print("3. View Insurance by Policy Id")
            print("4. Back")

            sub_choice = input("Enter your choice (1-4): ").strip()

            if sub_choice == "1":
                self.view_all_insurance()
            elif sub_choice == "2":
                self.view_insurance_by_vehicle_id()
            elif sub_choice == "3":
                self.view_insurance_by_policy_id()
            elif sub_choice == "4":
                break
            else:
                print("Invalid choice.")

    def view_all_insurance(self):
        policies = storage.load_policies()
        if not policies:
            print("No insurance records found.")
            return

        print("\nAll Insurance Records:")
        for p in policies:
            self._print_policy_details(p)

    def view_insurance_by_vehicle_id(self):
        vehicle_id = input("Enter Vehicle Id: ").strip()
        policies = storage.load_policies()
        matching = [p for p in policies if p.vehicle_no.lower() == vehicle_id.lower()]

        if not matching:
            print(f"No insurance record found for Vehicle ID '{vehicle_id}'.")
            return

        print(f"\nInsurance Details for Vehicle ID {vehicle_id}:")
        for p in matching:
            self._print_policy_details(p)

    def view_insurance_by_policy_id(self):
        raw_id = input("Enter Policy Id: ").strip()
        if not raw_id.isdigit():
            print("Invalid Policy ID.")
            return

        policy_no = int(raw_id)
        policies = storage.load_policies()
        found = next((p for p in policies if p.policy_no == policy_no), None)

        if not found:
            print(f"No insurance record found for Policy ID {policy_no}.")
            return

        print(f"\nInsurance Details for Policy ID {policy_no}:")
        self._print_policy_details(found)

    def _print_policy_details(self, p):
        print(f"PolicyNo    : {p.policy_no}")
        print(f"VehicleNo   : {p.vehicle_no}")
        print(f"VehicleType : {p.vehicle_type}")
        print(f"CustomerName: {p.customer_name}")
        print(f"EngineNo    : {p.engine_no}")
        print(f"ChasisNo    : {p.chasis_no}")
        print(f"PhoneNo     : {p.phone_no}")
        print(f"PremiumAmnt : {p.premium_amount}")
        print(f"Type        : {p.type}")
        print(f"FromDate    : {p.from_date}")
        print(f"ToDate      : {p.to_date}")
