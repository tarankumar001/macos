from datetime import datetime
from underwriter import Underwriter
import storage


def is_valid_password(password):
    has_alnum = any(c.isalnum() for c in password)
    has_special = any(not c.isalnum() and not c.isspace() for c in password)
    return has_alnum and has_special


class AdminService:
    def __init__(self):
        self.default_admin_id = "admin"
        self.default_admin_password = "admin123"

    def admin_login(self):
        print("\nAdministrator Login")
        user_id = input("Enter Admin User ID: ").strip()
        password = input("Enter Admin Password: ").strip()

        if user_id == self.default_admin_id and password == self.default_admin_password:
            print("Login successful.")
            return True
        else:
            print("Invalid credentials.")
            return False

    def admin_menu(self):
        while True:
            print("\nADMINISTRATOR MENU")
            print("1. Underwriter Registration")
            print("2. Search Underwriter by Id")
            print("3. Update Underwriter password")
            print("4. Delete Underwriter by Id")
            print("5. View All Underwriter")
            print("6. View All Vehicle specific to underWriter Id")
            print("7. Logout")

            choice = input("Enter your choice (1-7): ").strip()

            if choice == "1":
                self.register_underwriter()
            elif choice == "2":
                self.search_underwriter()
            elif choice == "3":
                self.update_underwriter_password()
            elif choice == "4":
                self.delete_underwriter()
            elif choice == "5":
                self.view_all_underwriters()
            elif choice == "6":
                self.view_vehicles_by_underwriter()
            elif choice == "7":
                print("Logging out.")
                break
            else:
                print("Invalid choice.")

    def register_underwriter(self):
        print("\nUnderwriter Registration")
        name = input("Enter Name: ").strip()
        while not name:
            print("Name cannot be empty.")
            name = input("Enter Name: ").strip()

        while True:
            dob = input("Enter Date of Birth (DD-MM-YYYY): ").strip()
            try:
                datetime.strptime(dob, "%d-%m-%Y")
                break
            except ValueError:
                print("Invalid Date format. Use DD-MM-YYYY.")

        while True:
            joining_date = input("Enter Joining Date (DD-MM-YYYY): ").strip()
            try:
                datetime.strptime(joining_date, "%d-%m-%Y")
                break
            except ValueError:
                print("Invalid Date format. Use DD-MM-YYYY.")


        while True:
            password = input("Enter Password: ").strip()
            if is_valid_password(password):
                break
            print("Invalid Password. Must contain alphanumeric characters and at least one special character.")

        underwriters = storage.load_underwriters()
        new_id = storage.generate_underwriter_id(underwriters)

        new_uw = Underwriter(new_id, name, dob, joining_date, password)
        underwriters.append(new_uw)
        storage.save_underwriters(underwriters)

        print(f"Underwriter registered successfully with Underwriter ID: {new_id}")

    def search_underwriter(self):
        while True:
            print("\nSearch Underwriter Menu")
            print("1. View all UnderWriter")
            print("2. View UnderWriter by Id")
            print("3. Go Back")
            sub_choice = input("Enter your choice (1-3): ").strip()

            if sub_choice == "1":
                self.view_all_underwriters()
            elif sub_choice == "2":
                self._search_underwriter_by_id()
            elif sub_choice == "3":
                break
            else:
                print("Invalid choice.")

    def _search_underwriter_by_id(self):
        while True:
            raw_id = input("Enter Underwriter Id: ").strip()
            if not raw_id.isdigit():
                print("\nInvalid UnderWriter Id")
                if not self._handle_invalid_retry():
                    break
                continue

            uw_id = int(raw_id)
            underwriters = storage.load_underwriters()
            found = next((u for u in underwriters if u.underwriter_id == uw_id), None)

            if found:
                print(f"\nUnderwriter Details:")
                print(f"Underwriter ID: {found.underwriter_id}")
                print(f"Name          : {found.name}")
                print(f"DOB           : {found.dob}")
                print(f"Joining Date  : {found.joining_date}")
                print(f"Password      : {found.password}")
                break
            else:
                print("\nInvalid UnderWriter Id")
                if not self._handle_invalid_retry():
                    break

    def update_underwriter_password(self):
        print("\nUpdate Underwriter Password")
        while True:
            raw_id = input("Enter Underwriter Id: ").strip()
            if not raw_id.isdigit():
                print("\nInvalid UnderWriter Id")
                if not self._handle_invalid_retry():
                    return
                continue

            uw_id = int(raw_id)
            underwriters = storage.load_underwriters()
            found = next((u for u in underwriters if u.underwriter_id == uw_id), None)

            if found:
                while True:
                    new_password = input("Enter new Password: ").strip()
                    if is_valid_password(new_password):
                        break
                    print("Invalid Password. Must contain alphanumeric characters and at least one special character.")

                found.password = new_password
                storage.save_underwriters(underwriters)
                print("Password updated successfully.")
                break
            else:
                print("\nInvalid UnderWriter Id")
                if not self._handle_invalid_retry():
                    break

    def delete_underwriter(self):
        print("\nDelete Underwriter")
        while True:
            raw_id = input("Enter Underwriter Id: ").strip()
            if not raw_id.isdigit():
                print("\nInvalid UnderWriter Id")
                if not self._handle_invalid_retry():
                    return
                continue

            uw_id = int(raw_id)
            underwriters = storage.load_underwriters()
            found = next((u for u in underwriters if u.underwriter_id == uw_id), None)

            if found:
                print(f"Confirm deletion for Underwriter {found.name} (ID: {found.underwriter_id})?")
                print("1. Yes")
                print("2. No")
                confirm = input("Enter choice (1-2): ").strip()
                if confirm == "1":
                    underwriters = [u for u in underwriters if u.underwriter_id != uw_id]
                    storage.save_underwriters(underwriters)
                    print("Underwriter record deleted.")
                else:
                    print("Deletion cancelled.")
                break
            else:
                print("\nInvalid UnderWriter Id")
                if not self._handle_invalid_retry():
                    break

    def view_all_underwriters(self):
        underwriters = storage.load_underwriters()
        if not underwriters:
            print("\nNo underwriters registered in the system.")
            return

        print("\nAll Underwriters:")
        for u in underwriters:
            print(f"ID: {u.underwriter_id} | Name: {u.name} | DOB: {u.dob} | Joining Date: {u.joining_date} | Password: {u.password}")

    def view_vehicles_by_underwriter(self):
        print("\nView Vehicles by Underwriter ID")
        raw_id = input("Enter Underwriter Id: ").strip()
        if not raw_id.isdigit():
            print("Invalid UnderWriter Id")
            return

        uw_id = int(raw_id)
        policies = storage.load_policies()
        matching_policies = [p for p in policies if p.underwriter_id == uw_id]

        if not matching_policies:
            print(f"No vehicle records found for Underwriter ID {uw_id}.")
            return

        print(f"\nVehicle Records for Underwriter ID {uw_id}:")
        for p in matching_policies:
            self._print_policy_details(p)

    def _handle_invalid_retry(self):
        print("1. Re-Enter UnderWriter Id")
        print("2. Go Back to the previous Screen")
        choice = input("Enter option (1-2): ").strip()
        return choice == "1"

    def _print_policy_details(self, p):
        print(f"PolicyNo    : {p.policy_no}")
        print(f"VehicleNo   : {p.vehicle_no}")
        print(f"VehicleType : {p.vehicle_type}")
        print(f"CustomerName: {p.customer_name}")
        print(f"EngineNo    : {p.engine_no}")
        print(f"ChasisNo    : {p.chasis_no}")
        print(f"PhoneNo     : {p.phone_no}")
        print(f"PremiumAmnt : {p.premium_amount}")
        print(f"Type        : {p.type}")
        print(f"FromDate    : {p.from_date}")
        print(f"ToDate      : {p.to_date}")
