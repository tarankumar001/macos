import sys
from admin_service import AdminService
from underwriter_service import UnderwriterService


def main():
    admin_service = AdminService()
    underwriter_service = UnderwriterService()

    while True:
        print("\nSTAR PROTECT VEHICLE INSURANCE")
        print("1. Administrator Login")
        print("2. Underwriter Login")
        print("3. Exit")

        choice = input("Select Role (1-3): ").strip()

        if choice == "1":
            if admin_service.admin_login():
                admin_service.admin_menu()
        elif choice == "2":
            if underwriter_service.underwriter_login():
                underwriter_service.underwriter_menu()
        elif choice == "3":
            print("Exiting application.")
            sys.exit(0)
        else:
            print("Invalid choice.")


if __name__ == "__main__":
    main()

