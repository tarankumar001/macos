import json
import os
from underwriter import Underwriter
from vehicle_insurance import VehicleInsurance

UNDERWRITERS_FILE = "underwriters.json"
POLICIES_FILE = "policies.json"


def load_underwriters():
    if not os.path.exists(UNDERWRITERS_FILE):
        return []
    try:
        with open(UNDERWRITERS_FILE, "r") as f:
            data = json.load(f)
            return [Underwriter.from_dict(item) for item in data]
    except Exception:
        return []


def save_underwriters(underwriters):
    try:
        with open(UNDERWRITERS_FILE, "w") as f:
            json.dump([u.to_dict() for u in underwriters], f, indent=2)
    except Exception as e:
        print(f"Error saving underwriters: {e}")


def load_policies():
    if not os.path.exists(POLICIES_FILE):
        return []
    try:
        with open(POLICIES_FILE, "r") as f:
            data = json.load(f)
            return [VehicleInsurance.from_dict(item) for item in data]
    except Exception:
        return []


def save_policies(policies):
    try:
        with open(POLICIES_FILE, "w") as f:
            json.dump([p.to_dict() for p in policies], f, indent=2)
    except Exception as e:
        print(f"Error saving policies: {e}")


def generate_underwriter_id(underwriters):
    if not underwriters:
        return 101
    return max(u.underwriter_id for u in underwriters) + 1


def generate_policy_no(policies):
    if not policies:
        return 1001
    return max(p.policy_no for p in policies) + 1
