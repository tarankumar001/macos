class Underwriter:
    def __init__(self, underwriter_id, name, dob, joining_date, password):
        self.underwriter_id = int(underwriter_id)
        self.name = name
        self.dob = dob
        self.joining_date = joining_date
        self.password = password

    def to_dict(self):
        return {
            "underwriter_id": self.underwriter_id,
            "name": self.name,
            "dob": self.dob,
            "joining_date": self.joining_date,
            "password": self.password
        }

    @classmethod
    def from_dict(cls, data):
        return cls(
            underwriter_id=data["underwriter_id"],
            name=data["name"],
            dob=data["dob"],
            joining_date=data["joining_date"],
            password=data["password"]
        )
