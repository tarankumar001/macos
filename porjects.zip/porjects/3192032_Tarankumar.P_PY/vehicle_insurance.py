def calculate_premium(vehicle_type, insurance_type):
    """
    Simple function to calculate premium based on vehicle type and insurance type.
    Can easily be modified later if premium values or formula change.
    """
    v_type = vehicle_type.lower()
    i_type = insurance_type.lower()
    
    if "2" in v_type:
        if "full" in i_type:
            return 1500.0
        else:
            return 750.0
    else:
        if "full" in i_type:
            return 5000.0
        else:
            return 2200.0


class VehicleInsurance:
    def __init__(self, policy_no, vehicle_no, vehicle_type, customer_name, engine_no, chasis_no, phone_no, insurance_type, premium_amount, from_date, to_date, underwriter_id):
        self.policy_no = int(policy_no)
        self.vehicle_no = vehicle_no
        self.vehicle_type = vehicle_type
        self.customer_name = customer_name
        self.engine_no = engine_no
        self.chasis_no = chasis_no
        self.phone_no = str(phone_no)
        self.type = insurance_type
        self.premium_amount = float(premium_amount)
        self.from_date = str(from_date)
        self.to_date = str(to_date)
        self.underwriter_id = int(underwriter_id)

    def to_dict(self):
        return {
            "policy_no": self.policy_no,
            "vehicle_no": self.vehicle_no,
            "vehicle_type": self.vehicle_type,
            "customer_name": self.customer_name,
            "engine_no": self.engine_no,
            "chasis_no": self.chasis_no,
            "phone_no": self.phone_no,
            "type": self.type,
            "premium_amount": self.premium_amount,
            "from_date": self.from_date,
            "to_date": self.to_date,
            "underwriter_id": self.underwriter_id
        }

    @classmethod
    def from_dict(cls, data):
        return cls(
            policy_no=data["policy_no"],
            vehicle_no=data["vehicle_no"],
            vehicle_type=data["vehicle_type"],
            customer_name=data["customer_name"],
            engine_no=data["engine_no"],
            chasis_no=data["chasis_no"],
            phone_no=data["phone_no"],
            insurance_type=data["type"],
            premium_amount=data["premium_amount"],
            from_date=data["from_date"],
            to_date=data["to_date"],
            underwriter_id=data["underwriter_id"]
        )
